
const launches = require('./launches.schema');
const planets = require('./plantes.schema');
// const launches = new Map();
const DEFAULT_FILGHT_NUMBER = 100;
let latestFlightNumber = 100;

const launch = {
    flightNumber: 100,
    mission: 'Kepler Exploration X',
    rocket: 'Explorer IS1',
    launchDate: new Date('December 27, 2030'),
    target: 'Kepler-442 b',
    customers: ['ZTM', 'ISRO'],
    upcoming: true,
    success: true
};

// launches.set(launch.flightNumber, launch);
// console.log(launches,'launches');
saveLaunch(launch);

async function existsLaunchWithId(launchId) {
    // return launches.has(launchId);
    return await launches.findOne({
        flightNumber: launchId
    });
}

async function getLastestFlightNumber() {
    const lastestLaunch = await launches
        .findOne()
        .sort('-flightNumber');

    if (!lastestLaunch) {
        return DEFAULT_FILGHT_NUMBER;
    }

    return lastestLaunch.flightNumber;
}

async function getAllLanuches() {
    // return Array.from(launches.values());
    return await launches.find({}, {
        '__id': 0, '__v': 0
    });
}


async function saveLaunch(launch) {
    const planet = await planets.findOne({
        keplerName: launch.target,
    });

    if (!planet) {
        throw new Error('No matching planet found');

        // console.log(`No matching planet found`)
    }
    await launches.findOneAndUpdate({
        flightNumber: launch.flightNumber
    }, launch, {
        upsert: true
    });
}

// async function addNewLaunch(launch) {
//     latestFlightNumber++;
//     launches.set(
//         latestFlightNumber,
//         Object.assign(launch, {
//             success: true,
//             upcoming: true,
//             customers: ['Zero to Mastery', "NASA"],
//             flightNumber: latestFlightNumber,
//         }));
// }


async function scheduleNewLaunch(launch) {
    const newFlightNumber = await getLastestFlightNumber() + 1;
    const newLaunch = Object.assign(launch, {
        success: true,
        upcoming: true,
        customers: ['Zero to Mastery', "NASA"],
        flightNumber: newFlightNumber,
    });

    await saveLaunch(newLaunch);
}

async function abortLaunchById(launchId) {
    // doubt
    // const aborted = launches.get(launchId);
    // aborted.upcoming = false;
    // aborted.success = false;
    // return aborted;

    const aborted = await launches.updateOne({
        flightNumber: launchId
    }, {
        upcoming: false,
        success: false
    });
    return aborted.ok === 1 && aborted.nModified === 1;

}

module.exports = {
    getAllLanuches,
    // addNewLaunch,
    existsLaunchWithId,
    abortLaunchById,
    scheduleNewLaunch,
};